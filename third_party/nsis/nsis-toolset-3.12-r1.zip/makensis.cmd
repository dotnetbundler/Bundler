@echo off
setlocal
set "NSISDIR=%~dp0common"
"%~dp0hosts\win-x86\makensis.exe" %*
exit /b %ERRORLEVEL%
